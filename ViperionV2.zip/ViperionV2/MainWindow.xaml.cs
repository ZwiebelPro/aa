﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace ViperionV2
{
    public partial class MainWindow : Window
    {
        [DllImport("Inject.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int ExecuteScript(string script, StringBuilder errorMessage, int errorMessageSize);

        public MainWindow()
        {
            InitializeComponent();
        }

        private void InjectButton_Click(object sender, RoutedEventArgs e)
        {
            string luaScript = TextBox.Text.Trim(); // Get Lua script from TextBox and trim whitespace

            if (string.IsNullOrEmpty(luaScript))
            {
                MessageBox.Show("Please enter a Lua script.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            const int maxErrorMessageSize = 256;
            StringBuilder errorMessage = new StringBuilder(maxErrorMessageSize);

            int result = ExecuteScript(luaScript, errorMessage, maxErrorMessageSize);

            if (result == 0)
            {
                MessageBox.Show("Script executed successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                string error = errorMessage.ToString().TrimEnd('\0');
                DisplayError($"Execution failed with error code {result}: {error}");
            }
        }

        private void DisplayError(string errorMessage)
        {
            MessageBox.Show($"Error: {errorMessage}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            TextBox.Clear(); // Clear the TextBox content
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            StartFadeOutBlurEffect();
        }

        private void StartFadeOutBlurEffect()
        {
            Storyboard fadeOutStoryboard = (Storyboard)this.Resources["FadeOutBlurEffect"];
            if (fadeOutStoryboard != null)
            {
                fadeOutStoryboard.Begin();
            }
        }

        private void Window_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            DragMove(); // Allow dragging the window
        }

        private void Window_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            this.Opacity = 0.75; // Restore opacity
        }

        private void Window_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            this.Opacity = 0.5; // Reduce opacity when mouse leaves
        }

        private void ExecuteButton_Click(object sender, RoutedEventArgs e)
        {
            // Implement Execute button functionality here if needed
        }
    }
}
